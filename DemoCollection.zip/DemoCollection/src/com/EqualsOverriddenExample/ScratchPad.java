package com.EqualsOverriddenExample;

import java.util.HashSet;
import java.util.Set;

class Student{
	public int id;
	public Student(int id) {
		this.id=id;
	}
	
	@Override
	public boolean equals(Object obj) {
		Student s= (Student)obj;
		return this.id==s.id;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		int hash=id;
		return hash %10;
	}

	
	
	
}
public class ScratchPad {
public static void main(String[] args) {
	Set<Student> set= new HashSet<>();
	Student s1=new Student(1);
	Student s2=new Student(1);
	set.add(s1);
	set.add(s2);
	for(Student s: set) {
		System.out.println(s.id);
		System.out.println(s.hashCode());
	}
	
}
}
