package com.example.Collection;

import java.util.HashSet;
import java.util.Set;

public class Set_Implementation_Example {
public static void main(String[] args) {
	Set<String> set= new HashSet<>();
	set.add("Pranay");
	set.add("Kumar");
	set.add("Chouhan");
	set.add("Hello");
	set.add("Hi");
	System.out.println(set);
	
	boolean b= set.add("Pranay");
	System.out.println(b);
}
}
