package com.example.Collection;

import java.util.HashMap;
import java.util.Map;

public class Hash_Map_Implementation {

	public static void main(String[] args) {
		String[] str = { "AA", "BB", "AA", "DD" };
		Map<String, Integer> map = new HashMap<>();
		for (int i = 0; i < str.length; i++) {
			if (map.containsKey(str[i])) {
				map.put(str[i], map.get(str[i]) + 1);
			} else {
				map.put(str[i], 1);
			}

		}
		System.out.println(map);
	}

}
