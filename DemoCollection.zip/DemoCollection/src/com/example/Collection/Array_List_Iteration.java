package com.example.Collection;

import java.util.ArrayList;
import java.util.Iterator;

public class Array_List_Iteration {
public static void main(String[] args) {
	ArrayList<String> arr= new ArrayList<>();
	arr.add("Pranay");
	arr.add("Kumar");
	arr.add("Chouhan");
	arr.add("Hello");
	arr.add("Hi");
	for(int i=0;i<arr.size(); i++) {
		String s=arr.get(i);
		System.out.println(s);
		 arr.remove(i);
	}
	for(String str: arr) {
		System.out.println(str);
		 arr.remove(str);
	}
	
Iterator<String> it= arr.iterator();
while(it.hasNext()) {
	String s= it.next();
	System.out.println(s);
	it.remove();
}

}
}
