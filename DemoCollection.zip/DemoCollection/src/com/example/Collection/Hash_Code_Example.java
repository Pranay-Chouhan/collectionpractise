package com.example.Collection;

public class Hash_Code_Example {
public static void main(String[] args) {
	//Object obj= new Object();
	//System.out.println(obj.hashCode());
	// remember the by default implementation of == amd equals in case of strings and other objects



}

}
